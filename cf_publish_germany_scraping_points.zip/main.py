# -*- coding: utf-8 -*-


from google.cloud import pubsub_v1, storage
import json
import random
import requests
import time


def publish(message):
    project_id = 'curbfood-data-platform'
    topic_id = 'germany-plz-scraping'
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)
    data = {'lat': message[1], 'lon': message[0]}
    message_json = json.dumps(data)
    message_bytes = message_json.encode('utf-8')
    future = publisher.publish(
            topic_path, data=message_bytes
            )
    future.result()

def publish_germany_scraping_points(request):
    """
    Cloud function to populate the topic
    """
    storage_client = storage.Client()

    bucket = storage_client.get_bucket('germany-plz-polygon')

    blob = bucket.get_blob('plz_sampled_points_10.json')
    string_data = blob.download_as_string().decode()
    json_data = json.loads(string_data)
    data = json_data['sampled_points']
    for plz in data:
        points = data[plz]
        for point in points:
            publish(point)

def _get_wolt_json(lat, lon):
    storage_client = storage.Client()
    bucket = storage_client.get_bucket('germany-plz-polygon')

    url = f'https://restaurant-api.wolt.com/v1/pages/delivery?lat={lat}&lon={lon}'
    response = requests.get(url)
    if response.status_code == 200:
        fname = f"wolt_restaurant_data/{lat}_{lon}.json"
        blob = bucket.blob(fname)
        data = response.content
        blob.upload_from_string(data)
    if response.status_code != 200:
        print(f"Warning, Warning, Warning: {response.status_code}")

def scrapy_wolt(event, context):
    """
    Cloud function to scrape the wolt data
    """
    import base64
    message_bytes = base64.b64decode(event['data'])
    message = json.loads(message_bytes.decode('utf-8'))
    _get_wolt_json(message['lat'], message['lon'])

