# Cloud function to publish
gcloud functions deploy publish_points --runtime python37 --trigger-http --region=europe-west3









