# Cloud function to publish
gcloud functions deploy publish_germany_scraping_points   --runtime python37
--trigger-http --region=europe-west3 --allow-unauthenticated


# Cloud function to consume 

gcloud functions deploy scrapy_wolt  --runtime python37
--trigger-topic=germany-plz-scraping  --region=europe-west3
--allow-unauthenticated









